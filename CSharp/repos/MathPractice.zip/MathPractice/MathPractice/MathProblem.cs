﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathPractice
{
    class MathProblem
    {
        public int i, j, ans, op;
        private Random r = new Random(); 
        public MathProblem()
        {
            //randomly generate i, j, and op

            //using i, j, and op, compute answer 
            //if op is 0 --> addition
            //if op is 1 --> subtraction
            //if op is 2 --> division 
            //if op is 3 --> multiplication 

        }

        public bool checkProblem(int guess)
        {
            //if the guess is the ans, return true
            //else return false
            return false; 
        }

    }
}
