﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MagicEight
{
    public partial class Form1 : Form
    {
        Random r; 
        string[] answers = //create a string array of possible answers 
        public Form1()
        {
            InitializeComponent();
            r = new Random();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            questionBox.Text = "";
            answerBox.Text = //select a random value from the answers array and put the value here
        }
    }
}
