﻿
namespace TickTack
{
    partial class TicTak
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.oWinText = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.xWinTxt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.curTurn = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button33);
            this.panel1.Controls.Add(this.button32);
            this.panel1.Controls.Add(this.button31);
            this.panel1.Controls.Add(this.button23);
            this.panel1.Controls.Add(this.button22);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(898, 923);
            this.panel1.TabIndex = 0;
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button33.Location = new System.Drawing.Point(635, 658);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(233, 189);
            this.button33.TabIndex = 9;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button_Click);
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button32.Location = new System.Drawing.Point(330, 658);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(233, 189);
            this.button32.TabIndex = 8;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button_Click);
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button31.Location = new System.Drawing.Point(25, 658);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(233, 189);
            this.button31.TabIndex = 7;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button_Click);
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button23.Location = new System.Drawing.Point(635, 424);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(233, 189);
            this.button23.TabIndex = 6;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button_Click);
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button22.Location = new System.Drawing.Point(330, 424);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(233, 189);
            this.button22.TabIndex = 5;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button21.Location = new System.Drawing.Point(25, 424);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(233, 189);
            this.button21.TabIndex = 4;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button13.Location = new System.Drawing.Point(635, 190);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(233, 189);
            this.button13.TabIndex = 3;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button12.Location = new System.Drawing.Point(330, 190);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(233, 189);
            this.button12.TabIndex = 2;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button_Click);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button11.Location = new System.Drawing.Point(25, 190);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(233, 189);
            this.button11.TabIndex = 1;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.oWinText);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.xWinTxt);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.curTurn);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(893, 162);
            this.panel2.TabIndex = 0;
            // 
            // oWinText
            // 
            this.oWinText.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.oWinText.AutoSize = true;
            this.oWinText.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.oWinText.Location = new System.Drawing.Point(759, 44);
            this.oWinText.Name = "oWinText";
            this.oWinText.Size = new System.Drawing.Size(109, 106);
            this.oWinText.TabIndex = 5;
            this.oWinText.Text = "--";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(777, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "O Wins";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // xWinTxt
            // 
            this.xWinTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.xWinTxt.AutoSize = true;
            this.xWinTxt.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.xWinTxt.Location = new System.Drawing.Point(25, 44);
            this.xWinTxt.Name = "xWinTxt";
            this.xWinTxt.Size = new System.Drawing.Size(109, 106);
            this.xWinTxt.TabIndex = 3;
            this.xWinTxt.Text = "--";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "X Wins";
            // 
            // curTurn
            // 
            this.curTurn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.curTurn.AutoSize = true;
            this.curTurn.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.curTurn.Location = new System.Drawing.Point(376, 44);
            this.curTurn.Name = "curTurn";
            this.curTurn.Size = new System.Drawing.Size(141, 106);
            this.curTurn.TabIndex = 1;
            this.curTurn.Text = "---";
            this.curTurn.Click += new System.EventHandler(this.curTurn_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(371, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current Turn";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TicTak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 947);
            this.Controls.Add(this.panel1);
            this.Name = "TicTak";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label curTurn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label oWinText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label xWinTxt;
        private System.Windows.Forms.Label label3;
    }
}

