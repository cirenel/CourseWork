﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaOrder
{
    public class Item
    {
        protected double price; 


        public Item()
        {

        }



    }
}
