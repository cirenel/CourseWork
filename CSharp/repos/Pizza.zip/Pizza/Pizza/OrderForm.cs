﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaOrder
{
    public partial class OrderForm : Form
    {
        public OrderForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PizzaOrderForm p = new PizzaOrderForm();
            p.ShowDialog();

            Pizza orderedPizza = p.getPizzaOrder();
           // MessageBox.Show(orderedPizza + "");
            listboxOrder.Items.Add(orderedPizza);

            p.Dispose();
        }
    }
}
