﻿
namespace PizzaOrder
{
    partial class PizzaOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.sizePanel = new System.Windows.Forms.Panel();
            this.radioL = new System.Windows.Forms.RadioButton();
            this.radioM = new System.Windows.Forms.RadioButton();
            this.radioS = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.toppingPanel = new System.Windows.Forms.Panel();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.extrasPanel = new System.Windows.Forms.Panel();
            this.cheeseBox = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.sauceBox = new System.Windows.Forms.CheckBox();
            this.textBoxSpecial = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.sizePanel.SuspendLayout();
            this.toppingPanel.SuspendLayout();
            this.extrasPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.sizePanel);
            this.flowLayoutPanel1.Controls.Add(this.toppingPanel);
            this.flowLayoutPanel1.Controls.Add(this.extrasPanel);
            this.flowLayoutPanel1.Controls.Add(this.textBoxSpecial);
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 6);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(493, 168);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // sizePanel
            // 
            this.sizePanel.Controls.Add(this.radioL);
            this.sizePanel.Controls.Add(this.radioM);
            this.sizePanel.Controls.Add(this.radioS);
            this.sizePanel.Controls.Add(this.label1);
            this.sizePanel.Location = new System.Drawing.Point(2, 1);
            this.sizePanel.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.sizePanel.Name = "sizePanel";
            this.sizePanel.Size = new System.Drawing.Size(88, 91);
            this.sizePanel.TabIndex = 0;
            // 
            // radioL
            // 
            this.radioL.Location = new System.Drawing.Point(8, 60);
            this.radioL.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.radioL.Name = "radioL";
            this.radioL.Size = new System.Drawing.Size(55, 17);
            this.radioL.TabIndex = 3;
            this.radioL.TabStop = true;
            this.radioL.Text = "Large";
            this.radioL.UseVisualStyleBackColor = true;
            // 
            // radioM
            // 
            this.radioM.AutoSize = true;
            this.radioM.Location = new System.Drawing.Point(8, 40);
            this.radioM.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.radioM.Name = "radioM";
            this.radioM.Size = new System.Drawing.Size(70, 19);
            this.radioM.TabIndex = 2;
            this.radioM.TabStop = true;
            this.radioM.Text = "Medium";
            this.radioM.UseVisualStyleBackColor = true;
            // 
            // radioS
            // 
            this.radioS.AutoSize = true;
            this.radioS.Location = new System.Drawing.Point(8, 21);
            this.radioS.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.radioS.Name = "radioS";
            this.radioS.Size = new System.Drawing.Size(54, 19);
            this.radioS.TabIndex = 1;
            this.radioS.TabStop = true;
            this.radioS.Text = "Small";
            this.radioS.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 4);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Size";
            // 
            // toppingPanel
            // 
            this.toppingPanel.Controls.Add(this.checkBox10);
            this.toppingPanel.Controls.Add(this.checkBox11);
            this.toppingPanel.Controls.Add(this.checkBox12);
            this.toppingPanel.Controls.Add(this.checkBox7);
            this.toppingPanel.Controls.Add(this.checkBox8);
            this.toppingPanel.Controls.Add(this.checkBox9);
            this.toppingPanel.Controls.Add(this.checkBox4);
            this.toppingPanel.Controls.Add(this.checkBox5);
            this.toppingPanel.Controls.Add(this.checkBox6);
            this.toppingPanel.Controls.Add(this.checkBox3);
            this.toppingPanel.Controls.Add(this.checkBox2);
            this.toppingPanel.Controls.Add(this.checkBox1);
            this.toppingPanel.Controls.Add(this.label2);
            this.toppingPanel.Location = new System.Drawing.Point(94, 1);
            this.toppingPanel.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.toppingPanel.Name = "toppingPanel";
            this.toppingPanel.Size = new System.Drawing.Size(391, 91);
            this.toppingPanel.TabIndex = 4;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(276, 61);
            this.checkBox10.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(102, 19);
            this.checkBox10.TabIndex = 12;
            this.checkBox10.Text = "Eternal Sorrow";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(276, 42);
            this.checkBox11.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(106, 19);
            this.checkBox11.TabIndex = 11;
            this.checkBox11.Text = "Unhusked corn";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(276, 22);
            this.checkBox12.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(49, 19);
            this.checkBox12.TabIndex = 10;
            this.checkBox12.Text = "Tofu";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(187, 60);
            this.checkBox7.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(71, 19);
            this.checkBox7.TabIndex = 9;
            this.checkBox7.Text = "Speench";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(187, 41);
            this.checkBox8.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(69, 19);
            this.checkBox8.TabIndex = 8;
            this.checkBox8.Text = "Poppers";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(187, 21);
            this.checkBox9.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(68, 19);
            this.checkBox9.TabIndex = 7;
            this.checkBox9.Text = "Peppers";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(98, 60);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(59, 19);
            this.checkBox4.TabIndex = 6;
            this.checkBox4.Text = "Onion";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(98, 41);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(78, 19);
            this.checkBox5.TabIndex = 5;
            this.checkBox5.Text = "Pineapple";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(98, 21);
            this.checkBox6.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(58, 19);
            this.checkBox6.TabIndex = 4;
            this.checkBox6.Text = "Olives";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(9, 60);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(59, 19);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Bacon";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(9, 41);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(52, 19);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "HaM";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(9, 21);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(77, 19);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Peppironi";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, -1);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Toppings";
            // 
            // extrasPanel
            // 
            this.extrasPanel.Controls.Add(this.cheeseBox);
            this.extrasPanel.Controls.Add(this.label3);
            this.extrasPanel.Controls.Add(this.sauceBox);
            this.extrasPanel.Location = new System.Drawing.Point(2, 94);
            this.extrasPanel.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.extrasPanel.Name = "extrasPanel";
            this.extrasPanel.Size = new System.Drawing.Size(88, 64);
            this.extrasPanel.TabIndex = 4;
            // 
            // cheeseBox
            // 
            this.cheeseBox.AutoSize = true;
            this.cheeseBox.Location = new System.Drawing.Point(2, 37);
            this.cheeseBox.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.cheeseBox.Name = "cheeseBox";
            this.cheeseBox.Size = new System.Drawing.Size(64, 19);
            this.cheeseBox.TabIndex = 14;
            this.cheeseBox.Text = "Cheese";
            this.cheeseBox.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Extras";
            // 
            // sauceBox
            // 
            this.sauceBox.AutoSize = true;
            this.sauceBox.Location = new System.Drawing.Point(2, 16);
            this.sauceBox.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.sauceBox.Name = "sauceBox";
            this.sauceBox.Size = new System.Drawing.Size(57, 19);
            this.sauceBox.TabIndex = 13;
            this.sauceBox.Text = "Sauce";
            this.sauceBox.UseVisualStyleBackColor = true;
            // 
            // textBoxSpecial
            // 
            this.textBoxSpecial.Location = new System.Drawing.Point(94, 94);
            this.textBoxSpecial.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.textBoxSpecial.Multiline = true;
            this.textBoxSpecial.Name = "textBoxSpecial";
            this.textBoxSpecial.PlaceholderText = "Special isntructions....";
            this.textBoxSpecial.Size = new System.Drawing.Size(263, 66);
            this.textBoxSpecial.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(361, 94);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 64);
            this.button1.TabIndex = 16;
            this.button1.Text = "Add to order...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PizzaOrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 177);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.Name = "PizzaOrderForm";
            this.Text = "PizzaOrderForm";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.sizePanel.ResumeLayout(false);
            this.sizePanel.PerformLayout();
            this.toppingPanel.ResumeLayout(false);
            this.toppingPanel.PerformLayout();
            this.extrasPanel.ResumeLayout(false);
            this.extrasPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel sizePanel;
        private System.Windows.Forms.RadioButton radioL;
        private System.Windows.Forms.RadioButton radioM;
        private System.Windows.Forms.RadioButton radioS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel toppingPanel;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel extrasPanel;
        private System.Windows.Forms.CheckBox cheeseBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox sauceBox;
        private System.Windows.Forms.TextBox textBoxSpecial;
        private System.Windows.Forms.Button button1;
    }
}